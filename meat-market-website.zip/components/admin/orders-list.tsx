'use client'

import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { ChevronRight } from 'lucide-react'
import { useOrderStore } from '@/lib/store'
import { orderStatusLabels, orderStatusColors } from '@/lib/mock-data'
import { Order, OrderStatus } from '@/lib/types'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'

const statusFlow: OrderStatus[] = ['received', 'preparing', 'smoking', 'finished', 'out_for_delivery', 'delivered']

export function OrdersList({ showAll = false }: { showAll?: boolean }) {
  const { orders, updateOrderStatus } = useOrderStore()

  const displayOrders = showAll ? orders : orders.slice(0, 5)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price)
  }

  const getNextStatus = (currentStatus: OrderStatus): OrderStatus | null => {
    const currentIndex = statusFlow.indexOf(currentStatus)
    if (currentIndex < statusFlow.length - 1) {
      return statusFlow[currentIndex + 1]
    }
    return null
  }

  const handleAdvanceStatus = (orderId: string, currentStatus: OrderStatus) => {
    const nextStatus = getNextStatus(currentStatus)
    if (nextStatus) {
      updateOrderStatus(orderId, nextStatus)
    }
  }

  if (orders.length === 0) {
    return (
      <Card className="border-[var(--border)] bg-[var(--card)]">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <p className="text-[var(--muted-foreground)]">Nenhum pedido encontrado</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-[var(--border)] bg-[var(--card)]">
      <CardHeader>
        <CardTitle className="text-[var(--foreground)]">
          {showAll ? 'Todos os Pedidos' : 'Pedidos Recentes'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className={showAll ? 'h-[600px]' : 'h-[400px]'}>
          <div className="space-y-4">
            {displayOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                formatPrice={formatPrice}
                onAdvanceStatus={handleAdvanceStatus}
                onChangeStatus={(status) => updateOrderStatus(order.id, status)}
              />
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

interface OrderCardProps {
  order: Order
  formatPrice: (price: number) => string
  onAdvanceStatus: (orderId: string, currentStatus: OrderStatus) => void
  onChangeStatus: (status: OrderStatus) => void
}

function OrderCard({ order, formatPrice, onAdvanceStatus, onChangeStatus }: OrderCardProps) {
  const nextStatus = statusFlow[statusFlow.indexOf(order.status) + 1]

  return (
    <div className="rounded-lg border border-[var(--border)] bg-[var(--background)] p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[var(--foreground)]">#{order.id}</span>
            <Badge className={cn('text-xs', orderStatusColors[order.status])}>
              {orderStatusLabels[order.status]}
            </Badge>
          </div>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            {order.customer.name} • {order.customer.phone}
          </p>
          <p className="text-xs text-[var(--muted-foreground)]">
            {format(new Date(order.createdAt), "dd/MM 'às' HH:mm", { locale: ptBR })}
          </p>
        </div>
        <div className="text-right">
          <span className="text-lg font-bold text-[var(--wine)]">
            {formatPrice(order.total)}
          </span>
          <p className="text-xs text-[var(--muted-foreground)]">
            {order.deliveryMethod === 'delivery' ? 'Delivery' : 'Retirada'}
          </p>
        </div>
      </div>

      <div className="mt-3 space-y-1">
        {order.items.map((item, idx) => (
          <div key={idx} className="flex justify-between text-sm">
            <span className="text-[var(--foreground)]">
              {item.quantity}x {item.product.name}
            </span>
            <span className="text-[var(--muted-foreground)]">
              {formatPrice(item.product.price * item.quantity)}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Select
          value={order.status}
          onValueChange={(v) => onChangeStatus(v as OrderStatus)}
        >
          <SelectTrigger className="h-8 w-[180px] border-[var(--border)] text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {statusFlow.map((status) => (
              <SelectItem key={status} value={status}>
                {orderStatusLabels[status]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {nextStatus && (
          <Button
            size="sm"
            onClick={() => onAdvanceStatus(order.id, order.status)}
            className="bg-[var(--wine)] text-white hover:bg-[var(--wine-dark)]"
          >
            {orderStatusLabels[nextStatus]}
            <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
}
