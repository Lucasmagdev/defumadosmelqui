'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Pencil, Trash2, Plus, Check, X } from 'lucide-react'
import { products as initialProducts, categories } from '@/lib/mock-data'
import { Product } from '@/lib/types'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { toast } from 'sonner'

export function ProductsManagement() {
  const [productsState, setProducts] = useState<Product[]>(initialProducts)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    category: '',
    imageUrl: '',
    videoUrl: '',
    available: true,
  })

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price)
  }

  const handleOpenDialog = (product?: Product) => {
    if (product) {
      setEditingProduct(product)
      setFormData(product)
    } else {
      setEditingProduct(null)
      setFormData({
        name: '',
        description: '',
        price: 0,
        category: '',
        imageUrl: '',
        videoUrl: '',
        available: true,
      })
    }
    setIsDialogOpen(true)
  }

  const handleSave = () => {
    if (!formData.name || !formData.price || !formData.category) {
      toast.error('Preencha todos os campos obrigatórios')
      return
    }

    if (editingProduct) {
      setProducts((prev) =>
        prev.map((p) =>
          p.id === editingProduct.id ? { ...p, ...formData } as Product : p
        )
      )
      toast.success('Produto atualizado!')
    } else {
      const newProduct: Product = {
        id: crypto.randomUUID(),
        name: formData.name!,
        description: formData.description || '',
        price: formData.price!,
        category: formData.category!,
        imageUrl: formData.imageUrl || 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&q=80',
        videoUrl: formData.videoUrl,
        available: formData.available ?? true,
      }
      setProducts((prev) => [...prev, newProduct])
      toast.success('Produto adicionado!')
    }
    setIsDialogOpen(false)
  }

  const handleDelete = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id))
    toast.success('Produto removido!')
  }

  const toggleAvailability = (id: string) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, available: !p.available } : p
      )
    )
  }

  return (
    <Card className="border-[var(--border)] bg-[var(--card)]">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-[var(--foreground)]">Produtos</CardTitle>
        <Button
          onClick={() => handleOpenDialog()}
          className="bg-[var(--wine)] text-white hover:bg-[var(--wine-dark)]"
        >
          <Plus className="mr-2 h-4 w-4" />
          Novo Produto
        </Button>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px]">
          <div className="space-y-4">
            {productsState.map((product) => (
              <div
                key={product.id}
                className="flex items-center gap-4 rounded-lg border border-[var(--border)] bg-[var(--background)] p-4"
              >
                <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg">
                  <Image
                    src={product.imageUrl}
                    alt={product.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-[var(--foreground)] truncate">
                      {product.name}
                    </h3>
                    <Badge variant={product.available ? 'default' : 'secondary'} className={product.available ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {product.available ? 'Disponível' : 'Indisponível'}
                    </Badge>
                  </div>
                  <p className="text-sm text-[var(--muted-foreground)] truncate">
                    {product.description}
                  </p>
                  <p className="text-sm font-medium text-[var(--wine)]">
                    {formatPrice(product.price)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={product.available}
                    onCheckedChange={() => toggleAvailability(product.id)}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handleOpenDialog(product)}
                    className="border-[var(--border)]"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handleDelete(product.id)}
                    className="border-[var(--border)] text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg bg-[var(--background)]">
          <DialogHeader>
            <DialogTitle className="text-[var(--foreground)]">
              {editingProduct ? 'Editar Produto' : 'Novo Produto'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Nome *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="border-[var(--border)]"
                placeholder="Nome do produto"
              />
            </div>
            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="border-[var(--border)]"
                placeholder="Descrição do produto"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Preço *</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                  className="border-[var(--border)]"
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <Label>Categoria *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(v) => setFormData({ ...formData, category: v })}
                >
                  <SelectTrigger className="border-[var(--border)]">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.slug}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>URL da Imagem</Label>
              <Input
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                className="border-[var(--border)]"
                placeholder="https://..."
              />
            </div>
            <div className="space-y-2">
              <Label>URL do Vídeo (opcional)</Label>
              <Input
                value={formData.videoUrl}
                onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                className="border-[var(--border)]"
                placeholder="https://youtube.com/embed/..."
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Disponível para venda</Label>
              <Switch
                checked={formData.available}
                onCheckedChange={(v) => setFormData({ ...formData, available: v })}
              />
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                className="flex-1 border-[var(--border)]"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSave}
                className="flex-1 bg-[var(--wine)] text-white hover:bg-[var(--wine-dark)]"
              >
                Salvar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
