'use client'

import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useOrderStore } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'

export function CustomersManagement() {
  const { customers, orders } = useOrderStore()

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price)
  }

  const getCustomerStats = (customerId: string) => {
    const customerOrders = orders.filter((o) => o.customerId === customerId)
    const totalSpent = customerOrders.reduce((sum, o) => sum + o.total, 0)
    const averageTicket = customerOrders.length > 0 ? totalSpent / customerOrders.length : 0

    const productCounts: Record<string, { name: string; count: number }> = {}
    customerOrders.forEach((order) => {
      order.items.forEach((item) => {
        if (!productCounts[item.product.id]) {
          productCounts[item.product.id] = { name: item.product.name, count: 0 }
        }
        productCounts[item.product.id].count += item.quantity
      })
    })
    const favorites = Object.values(productCounts)
      .sort((a, b) => b.count - a.count)
      .slice(0, 3)

    return {
      orderCount: customerOrders.length,
      totalSpent,
      averageTicket,
      favorites,
    }
  }

  if (customers.length === 0) {
    return (
      <Card className="border-[var(--border)] bg-[var(--card)]">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <p className="text-[var(--muted-foreground)]">Nenhum cliente cadastrado</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-[var(--border)] bg-[var(--card)]">
      <CardHeader>
        <CardTitle className="text-[var(--foreground)]">Clientes</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px]">
          <div className="space-y-4">
            {customers.map((customer) => {
              const stats = getCustomerStats(customer.id)
              return (
                <div
                  key={customer.id}
                  className="rounded-lg border border-[var(--border)] bg-[var(--background)] p-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <h3 className="font-semibold text-[var(--foreground)]">
                        {customer.name}
                      </h3>
                      <p className="text-sm text-[var(--muted-foreground)]">
                        {customer.phone}
                      </p>
                      {customer.email && (
                        <p className="text-sm text-[var(--muted-foreground)]">
                          {customer.email}
                        </p>
                      )}
                      <p className="mt-1 text-xs text-[var(--muted-foreground)]">
                        Cliente desde {format(new Date(customer.createdAt), "dd/MM/yyyy", { locale: ptBR })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-[var(--muted-foreground)]">Total gasto</p>
                      <p className="text-lg font-bold text-[var(--wine)]">
                        {formatPrice(stats.totalSpent)}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 grid gap-4 sm:grid-cols-3">
                    <div className="rounded-lg bg-[var(--secondary)] p-3">
                      <p className="text-xs text-[var(--muted-foreground)]">Pedidos</p>
                      <p className="text-xl font-bold text-[var(--foreground)]">
                        {stats.orderCount}
                      </p>
                    </div>
                    <div className="rounded-lg bg-[var(--secondary)] p-3">
                      <p className="text-xs text-[var(--muted-foreground)]">Ticket Médio</p>
                      <p className="text-xl font-bold text-[var(--foreground)]">
                        {formatPrice(stats.averageTicket)}
                      </p>
                    </div>
                    <div className="rounded-lg bg-[var(--secondary)] p-3">
                      <p className="text-xs text-[var(--muted-foreground)]">Favoritos</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {stats.favorites.length > 0 ? (
                          stats.favorites.map((fav, idx) => (
                            <Badge
                              key={idx}
                              variant="outline"
                              className="border-[var(--gold)] text-xs text-[var(--foreground)]"
                            >
                              {fav.name}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-xs text-[var(--muted-foreground)]">-</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 rounded-lg bg-[var(--muted)] p-3">
                    <p className="text-xs font-medium text-[var(--muted-foreground)]">Endereço</p>
                    <p className="text-sm text-[var(--foreground)]">
                      {customer.address.street}, {customer.address.number}
                      {customer.address.complement && ` - ${customer.address.complement}`}
                    </p>
                    <p className="text-sm text-[var(--foreground)]">
                      {customer.address.neighborhood}, {customer.address.city} - {customer.address.state}
                    </p>
                    <p className="text-sm text-[var(--foreground)]">
                      CEP: {customer.address.zipCode}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
