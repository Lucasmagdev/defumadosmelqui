'use client'

import { useState } from 'react'
import { products, categories } from '@/lib/mock-data'
import { ProductCard } from '@/components/product-card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function ProductCatalog() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  const filteredProducts = selectedCategory
    ? products.filter((p) => p.category === selectedCategory)
    : products

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-2">
        <Button
          variant={selectedCategory === null ? 'default' : 'outline'}
          onClick={() => setSelectedCategory(null)}
          className={cn(
            'transition-all',
            selectedCategory === null
              ? 'bg-[var(--wine)] text-white hover:bg-[var(--wine-dark)]'
              : 'border-[var(--border)] text-[var(--foreground)] hover:border-[var(--wine)] hover:text-[var(--wine)]'
          )}
        >
          Todos
        </Button>
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.slug ? 'default' : 'outline'}
            onClick={() => setSelectedCategory(category.slug)}
            className={cn(
              'transition-all',
              selectedCategory === category.slug
                ? 'bg-[var(--wine)] text-white hover:bg-[var(--wine-dark)]'
                : 'border-[var(--border)] text-[var(--foreground)] hover:border-[var(--wine)] hover:text-[var(--wine)]'
            )}
          >
            {category.name}
          </Button>
        ))}
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="py-12 text-center">
          <p className="text-[var(--muted-foreground)]">
            Nenhum produto encontrado nesta categoria.
          </p>
        </div>
      )}
    </div>
  )
}
