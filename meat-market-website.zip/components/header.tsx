'use client'

import Link from 'next/link'
import { ShoppingCart, Menu, X, Flame } from 'lucide-react'
import { useState } from 'react'
import { useCartStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'

const navLinks = [
  { href: '/', label: 'Cardápio' },
  { href: '/carrinho', label: 'Carrinho' },
]

export function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const itemCount = useCartStore((state) => state.getItemCount())

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--border)] bg-[var(--background)]/95 backdrop-blur supports-[backdrop-filter]:bg-[var(--background)]/80">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--wine)]">
            <Flame className="h-5 w-5 text-[var(--gold)]" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold text-[var(--wine)]">Lima&apos;s</span>
            <span className="text-xs font-medium uppercase tracking-wider text-[var(--gold)]">Meat Market</span>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-[var(--foreground)] transition-colors hover:text-[var(--wine)]"
            >
              {link.label}
            </Link>
          ))}
          <Link href="/carrinho">
            <Button variant="outline" size="sm" className="relative border-[var(--wine)] text-[var(--wine)] hover:bg-[var(--wine)] hover:text-white">
              <ShoppingCart className="h-4 w-4" />
              {itemCount > 0 && (
                <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-[var(--wine)] text-xs text-white">
                  {itemCount}
                </span>
              )}
            </Button>
          </Link>
        </nav>

        <div className="flex items-center gap-4 md:hidden">
          <Link href="/carrinho" className="relative">
            <ShoppingCart className="h-6 w-6 text-[var(--wine)]" />
            {itemCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-[var(--wine)] text-xs text-white">
                {itemCount}
              </span>
            )}
          </Link>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] bg-[var(--background)]">
              <div className="flex flex-col gap-6 pt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="text-lg font-medium text-[var(--foreground)] transition-colors hover:text-[var(--wine)]"
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
